<!DOCTYPE html>
<html> 
<head>
<title>Drug Interactions</title>
<link rel="stylesheet" href="Drug_Interactions.css">
</head>

<body>
<div id="Title">
<h1>DRUG PRESCRIPTION PORTAL</h1>
</div>

<div id="form">
<form action="submit_drugs.php" method=post>
Drug 1: 
<input type="text" name="drug1"><br/><br/>
Drug 2: 
<input type="text" name="drug2"><br/><br/>

<input type="submit" value="Prescribe"> 
</form>
</div>

</body>
</html>
