Step 1
Put entire Drug_Interactions folder in wamp www folder

Step 2
Run the php file "Drug_Interactions/Drug_Interactions2" from the LocalHost 

NOTES:
Enter the name of the drugs that you want to find interactions between. 
The submit_drugs.php file does the processing of drug names and retrieval of RXCUI codes 

